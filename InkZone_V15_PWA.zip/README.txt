INKZONE V15 PWA

Mục tiêu:
- Chạy như Web App trên iPhone/Android.
- PDF/JPEG được chọn trực tiếp trong trình duyệt.
- PDF được render bằng Mozilla PDF.js 6.3.289.
- Tự đọc kích thước PDF theo điểm PDF và đổi sang mm.
- Chia toàn bộ khổ máy thành 21 zone.
- Artwork mặc định căn giữa.
- Tính RGB -> CMYK coverage theo từng zone.
- Coverage -> Ink Key bằng 10 điểm hiệu chuẩn riêng cho C/M/Y/K.
- Lưu profile vào bộ nhớ trình duyệt.
- Xuất CSV.

QUAN TRỌNG:
- Đây là phân tích coverage từ ảnh render, không phải RIP/TIFFSEP/ICC production separation.
- V15 cần chạy qua HTTPS/web server để PWA hoạt động đúng. Không mở index.html trực tiếp từ Files trên iPhone.
- V15 dùng PDF.js từ jsDelivr nên lần đầu cần Internet. Sau khi app shell được cache, khả năng offline còn tùy trình duyệt và việc cache thư viện PDF.js.

CÁCH ĐƯA LÊN WEB:
1. Giải nén ZIP.
2. Upload 4 file/thư mục lên một static host HTTPS, ví dụ GitHub Pages.
3. Mở URL bằng Safari.
4. Chia sẻ -> Thêm vào Màn hình chính.
