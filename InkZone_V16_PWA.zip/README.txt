# InkZone V16
Machine View + Artwork Fullscreen for 21 Ink Keys.

- K → M → C → Y
- 21 Ink Keys per color
- Fullscreen Artwork View
- Fit / 100% / Machine Sheet / 21 Zone overlay
- Pinch zoom and pan on iPhone
- Keeps the V15.5.1 calculation UI as the base
- This V16 does NOT claim a production RIP/CIP3 separation engine; calibration remains machine-profile dependent.
